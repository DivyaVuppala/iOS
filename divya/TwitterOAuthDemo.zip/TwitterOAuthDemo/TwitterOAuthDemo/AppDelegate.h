//
//  AppDelegate.h
//  TwitterOAuthDemo
//
//  Created by Divya Vuppala on 29/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

