//
//  ViewController.m
//  TwitterOAuthDemo
//
//  Created by Divya Vuppala on 29/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "ViewController.h"

NSString *strClientKey=@"NAsHuSMgnelv7FhcTFx2Q7t3P";
NSString *strClientSecret=@"dHhGYxRkb31RqwU5xnCWOAVdp4YIoDzMQoIugUVZm0vofG2py7";
NSString *callBack=@"oob";

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.consumer = [[OAConsumer alloc] initWithKey:strClientKey secret:strClientSecret];
    NSURL *requestTokenUrl = [NSURL URLWithString:@"https://api.twitter.com/oauth/request_token"];

    OAMutableURLRequest* requestTokenRequest=[[OAMutableURLRequest alloc] initWithURL:requestTokenUrl consumer:self.consumer token:nil realm:nil signatureProvider:nil];
    OARequestParameter* callbackParam = [[OARequestParameter alloc] initWithName:@"oauth_callback" value:callBack];
    [requestTokenRequest setHTTPMethod:@"POST"];
    [requestTokenRequest setParameters:[NSArray arrayWithObject:callbackParam]];
    
    OADataFetcher* dataFetcher = [[OADataFetcher alloc] init];
    
    [dataFetcher fetchDataWithRequest:requestTokenRequest delegate:self didFinishSelector:@selector(didReceiveRequestToken:data:) didFailSelector:@selector(didFailOAuth)];
    
    
    
}


- (void)didReceiveRequestToken:(OAServiceTicket*)ticket data:(NSData*)data {
    NSString* httpBody = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    self.requestToken = [[OAToken alloc] initWithHTTPResponseBody:httpBody];
    
    NSURL* authorizeUrl = [NSURL URLWithString:@"https://api.twitter.com/oauth/authorize"];
    OAMutableURLRequest* authorizeRequest = [[OAMutableURLRequest alloc] initWithURL:authorizeUrl                                                                     consumer:nil
                                                                               token:nil
                                                                               realm:nil
                                                                   signatureProvider:nil];
    NSString* oauthToken = self.requestToken.key;
    NSLog(@"%@",oauthToken);
    OARequestParameter* oauthTokenParam = [[OARequestParameter alloc] initWithName:@"oauth_token" value:oauthToken];
    [authorizeRequest setParameters:[NSArray arrayWithObject:oauthTokenParam]];
    
    [self.webView loadRequest:authorizeRequest];
}


-(void)didFailOAuth{
    NSLog(@"failed");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
