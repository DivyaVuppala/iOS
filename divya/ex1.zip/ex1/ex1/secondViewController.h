//
//  secondViewController.h
//  ex1
//
//  Created by Divya Vuppala on 02/03/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "ViewController.h"

@interface secondViewController : ViewController
@property (weak, nonatomic) IBOutlet UILabel *lbl1;
@property(strong,nonatomic) NSString*str1;
-(void) str1:(NSString *)str1;
@end
