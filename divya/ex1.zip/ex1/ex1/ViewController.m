//
//  ViewController.m
//  ex1
//
//  Created by Divya Vuppala on 02/03/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "ViewController.h"
#import "secondViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    secondViewController *svc=segue.destinationViewController;
    if([sender isKindOfClass:[UIButton class]]){
        if([segue.destinationViewController isKindOfClass:[secondViewController class]])
        {
            [svc str1:self.text1.text];
            
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn1:(id)sender {
    
}
@end
