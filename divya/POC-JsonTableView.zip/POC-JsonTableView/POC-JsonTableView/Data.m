//
//  Data.m
//  POC-JsonTableView
//
//  Created by Divya Vuppala on 27/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "Data.h"

@implementation Data

// method to get data from Local JSON file
-(NSDictionary *)getData
{
    NSString *filePath=[[NSBundle mainBundle]pathForResource:@"jsonparsetutorial" ofType:@"json"];
    NSData *data=[NSData dataWithContentsOfFile:filePath];
    NSError *error;
    NSDictionary *dictionary=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
    return dictionary;
}

// method to get data from URL
-(NSDictionary *)getDataFromURL
{
    NSData *data=[NSData dataWithContentsOfURL:[NSURL URLWithString:@"http://www.androidbegin.com/tutorial/jsonparsetutorial.txt"]];
    
    NSError *error;
    NSDictionary *dictionary=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
    
        return dictionary;
                  
}

+(instancetype)dataObj
{
    static Data *dataObj;
    if(!dataObj)
    {
        dataObj=[[Data alloc]init];
    }
    return dataObj;
}

@end
