//
//  Data.h
//  POC-JsonTableView
//
//  Created by Divya Vuppala on 27/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Data : NSObject

-(NSDictionary *)getData;
-(NSDictionary *)getDataFromURL;

+(instancetype)dataObj;

@end
