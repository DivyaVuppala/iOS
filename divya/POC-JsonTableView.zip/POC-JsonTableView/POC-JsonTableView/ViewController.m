//
//  ViewController.m
//  POC-JsonTableView
//
//  Created by Divya Vuppala on 27/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "ViewController.h"
#import "Data.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
   
    Data *dataObj=[Data dataObj];
    
    // calling getData method to populate tableview from local JSON file
       self.dictionary =[dataObj getData];
    //calling getDataFromURL method to populate tableview from network
     //  self.dictionary=[dataObj getDataFromURL];
 

    self.dataArray=[self.dictionary objectForKey:@"worldpopulation"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if(!cell)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
    }
  

    dispatch_queue_t downloadQueue=dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0);
    dispatch_async(downloadQueue, ^{
        
        NSURL *url=[NSURL URLWithString:[self.dataArray[indexPath.row] objectForKey:@"flag"]];
        NSData *data   =[[NSData alloc]initWithContentsOfURL:url];
        UIImage* image = [[UIImage alloc] initWithData:data];
        dispatch_sync(dispatch_get_main_queue(), ^{
            cell.imageView.image=image;
          
            cell.textLabel.text=[self.dataArray[indexPath.row] objectForKey:@"country"];
            cell.detailTextLabel.text=[self.dataArray[indexPath.row] objectForKey:@"population"];
            
        });
        
        
    });

    
    


    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

//-(UIImage*)downloadImageAtIndex:(NSInteger)index
//{
//    
//    
//}

@end
