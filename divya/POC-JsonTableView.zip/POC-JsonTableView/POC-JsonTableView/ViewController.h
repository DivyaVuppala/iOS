//
//  ViewController.h
//  POC-JsonTableView
//
//  Created by Divya Vuppala on 27/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface ViewController : UITableViewController

@property (nonatomic,strong)NSDictionary *dictionary;
@property (nonatomic,strong)NSArray *dataArray;


@end

