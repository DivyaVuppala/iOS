//
//  DetailViewController.m
//  FirstApp
//
//  Created by Madhukumar on 16/02/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.activityIndicator startAnimating];
    
    // Do any additional setup after loading the view.
    self.title=self.passedName;
    
    // loading PDF to webView if pdfs are saved in the app itself
//    NSString *path = [[NSBundle mainBundle] pathForResource:self.passedName ofType:@"pdf"];
//    NSURL *targetURL = [NSURL fileURLWithPath:path];
//    NSURLRequest *request = [NSURLRequest requestWithURL:targetURL];
//    [self.webView loadRequest:request];
    
    
    //loading PDF to webView from a remote URL
    NSURL *myUrl = [NSURL URLWithString:@"http://www.adobe.com/content/dam/Adobe/en/devnet/acrobat/pdfs/PDF32000_2008.pdf"];
    NSURLRequest *myRequest = [NSURLRequest requestWithURL:myUrl];
    [self.webView loadRequest:myRequest];
    
    
}


- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self.activityIndicator stopAnimating];
    self.activityIndicator.hidden = YES;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
