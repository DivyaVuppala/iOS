//
//  RegisterViewController.m
//  FirstApp
//
//  Created by Madhukumar on 16/02/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "RegisterViewController.h"

@interface RegisterViewController ()
@property BOOL passwordValid,emailValid;
@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
        // Do any additional setup after loading the view.
    [self.firstNameTextField becomeFirstResponder];
    
    self.textFieldsArray=@[self.firstNameTextField,self.lastNameTextField,self.passwordTextField,self.confirmPasswordTextField,self.emailTextField];
    
    NSString *savedFirstName=[[NSUserDefaults standardUserDefaults]valueForKey:@"firstName"];
    NSString *savedLastName=[[NSUserDefaults standardUserDefaults]valueForKey:@"lastName"];
    NSString *savedPassword=[[NSUserDefaults standardUserDefaults]valueForKey:@"password"];
    NSString *savedConfirmPassword=[[NSUserDefaults standardUserDefaults]valueForKey:@"confirmPassword"];
    NSString *savedEmail=[[NSUserDefaults standardUserDefaults]valueForKey:@"email"];
    
    if(savedFirstName!=nil)
    {
        self.firstNameTextField.text=savedFirstName;
        [self.firstNameTextField setEnabled:NO];
        
        self.lastNameTextField.text=savedLastName;
        [self.lastNameTextField setEnabled:NO];
        
        self.passwordTextField.text=savedPassword;
        [self.passwordTextField setEnabled:NO];
        
        self.confirmPasswordTextField.text=savedConfirmPassword;
        [self.confirmPasswordTextField setEnabled:NO];
    
        self.emailTextField.text=savedEmail;
        [self.emailTextField setEnabled:NO];
        
        [self.regButton setHidden:YES];
        
    }
    
       
}


// when cursor enters Email Field animate the view a bit to upward direction
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField==self.emailTextField)
    {
        [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
            [self.view setFrame:CGRectMake(0, -60, self.view.frame.size.width, self.view.frame.size.height)];} completion:nil];
    }
}

// restoring the view after filling the email Field
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.emailTextField resignFirstResponder];
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self.view setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];} completion:nil];
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField==self.emailTextField)
    {
        [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
            [self.view setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];} completion:nil];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


// function to be called when returnKey is pressed
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
  
    int i;
    for ( i=0; i<self.textFieldsArray.count-1; i++)
    {
        if(textField==self.textFieldsArray[i])
            {
                [self.textFieldsArray[i+1] becomeFirstResponder];
            }
        
    }
    
    if(textField==self.textFieldsArray[i])
    {
        [self registerButton:nil];
    }
    
    return YES;
}




- (IBAction)registerButton:(UIButton *)sender
{
    // calling the method to validate the fields
   
    if ([self validateTheFields] ) {
        //if validation is successful allow the user to Login
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"alert" message:@"Registered successfully" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",@"Login",nil];
        [alert show];
        
    }
   
    

    [[NSUserDefaults standardUserDefaults]setValue:self.firstNameTextField.text forKey:@"firstName"];
    [[NSUserDefaults standardUserDefaults]setValue:self.lastNameTextField.text forKey:@"lastName"];
     [[NSUserDefaults standardUserDefaults]setValue:self.passwordTextField.text forKey:@"password"];
     [[NSUserDefaults standardUserDefaults]setValue:self.confirmPasswordTextField.text forKey:@"confirmPassword"];
    [[NSUserDefaults standardUserDefaults]setValue:self.emailTextField.text forKey:@"email"];

    
    
    
}
    
    

-(BOOL)validateTheFields{
    UIAlertView *alert;

  
        if(self.firstNameTextField.text.length!=0)
        {
            if(self.lastNameTextField.text.length!=0)
            {
                //password validation
                BOOL lowerCaseLetter=NO,upperCaseLetter=NO,digit=NO,specialCharacter = NO;
                
                if(self.passwordTextField.text.length>=8)
                {
                    for (int i = 0; i < [self.passwordTextField.text length]; i++)
                    {
                        unichar c = [self.passwordTextField.text characterAtIndex:i];
                        if(!lowerCaseLetter)
                        {
                            lowerCaseLetter = [[NSCharacterSet lowercaseLetterCharacterSet] characterIsMember:c];
                        }
                        if(!upperCaseLetter)
                        {
                            upperCaseLetter = [[NSCharacterSet uppercaseLetterCharacterSet] characterIsMember:c];
                        }
                        if(!digit)
                        {
                            digit = [[NSCharacterSet decimalDigitCharacterSet] characterIsMember:c];
                        }
                        if(!specialCharacter)
                        {
                            specialCharacter = [[NSCharacterSet characterSetWithCharactersInString:@"!&~@#$%-*)(^-+"] characterIsMember:c];
                        }
                    }
                    if(specialCharacter && digit && lowerCaseLetter && upperCaseLetter)
                    {
                        //confirm password validation
                        if ([self.confirmPasswordTextField.text isEqualToString:self.passwordTextField.text])
                        {
                            //email validation
                            NSString *emailRegex = @"[A-Z0-9a-z]+@[A-Za-z]+\\.[A-Za-z]{2,6}";
                            NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
                            
                            if ([emailTest evaluateWithObject:self.emailTextField.text])
                            {
                                return YES;
                            }
                            else
                            {
                                //alert for invalid email
                                alert=[[UIAlertView alloc]initWithTitle:@"Oops!" message:@"Please enter valid email address" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
                                [alert show];
                                return NO;
                            }

                        }
                        else
                        {
                            
                            //alert for confirm password invalid
                            alert=[[UIAlertView alloc]initWithTitle:@"Error!" message:@"Password and Confirm Password mismatch" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
                            [alert show];
                            return NO;
                        }
                    }
                    else
                    {
                        //alert for invalid password
                        alert=[[UIAlertView alloc]initWithTitle:@"Invalid Password" message:@"Please Ensure that you have at least one lower case letter, one upper case letter, one digit and one special character" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
                        [alert show];
                        return NO;
                        
                    }
                }
                else
                {
                    //alert for length more than 8
                    alert=[[UIAlertView alloc]initWithTitle:@"Oops!" message:@"Password length should be more than 8 characters" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
                    [alert show];
                    return NO;
                    
                }

            }
            else
            {
                alert=[[UIAlertView alloc]initWithTitle:@"Missing Field" message:@"enter lastname" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
                [alert show];
                return NO;
            }
            
        }
        else
        {
            alert=[[UIAlertView alloc]initWithTitle:@"Missing Field" message:@"enter firstname" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alert show];
            return NO;
        }
    
  
}


// customizing the alertView

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex==1)
    {
        [self performSegueWithIdentifier:@"RegisterToLoginSegue" sender:nil];
        

        
    }
}
@end
