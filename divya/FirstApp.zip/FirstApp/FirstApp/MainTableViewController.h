//
//  MainTableViewController.h
//  FirstApp
//
//  Created by Madhukumar on 16/02/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTableViewController : UITableViewController

@property(nonatomic,strong) NSArray *listArray;
@property(nonatomic,strong)NSString *name;

@end
