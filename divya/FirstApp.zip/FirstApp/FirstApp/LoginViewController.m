//
//  LoginViewController.m
//  FirstApp
//
//  Created by Madhukumar on 16/02/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
    // Retrieving the data from session
    NSString *savedEmail=[[NSUserDefaults standardUserDefaults]valueForKey:@"email"];
    
    // Checking if the session is Active
    if(savedEmail==nil)
    {
        
    }
    else
    {
        self.emailTextField.text=savedEmail;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

// An alert showing Login Status 
- (IBAction)loginButton:(UIButton *)sender {
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Login successful" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alert show];
}
@end
