//
//  TweetsTableViewController.m
//  FHSTwitterDemo
//
//  Created by Divya Vuppala on 04/05/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "TweetsTableViewController.h"

@interface TweetsTableViewController ()

@end

@implementation TweetsTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tweetsDictionary=[[NSDictionary alloc]init];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self listResults];
}

-(void)listResults
{
    self.tweetsDictionary=[[FHSTwitterEngine sharedEngine] searchTweetsWithQuery:self.searchTweetsString count:100
                      ];
    NSLog(@"%@",[self.tweetsDictionary objectForKey:@"statuses"][0] );
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return ((NSArray*)[self.tweetsDictionary objectForKey:@"statuses"]).count;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"tweetCell" forIndexPath:indexPath];
    

    NSDictionary *currentObject=[self.tweetsDictionary objectForKey:@"statuses"][indexPath.row];

    dispatch_queue_t downloadQueue=dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0);
        dispatch_async(downloadQueue, ^{
    
    
            NSData *imageData=[NSData dataWithContentsOfURL:[NSURL URLWithString:[[currentObject objectForKey:@"user"]objectForKey:@"profile_image_url"]]];
            dispatch_sync(dispatch_get_main_queue(), ^{
    
                cell.imageView.image=[UIImage imageWithData:imageData];
                cell.textLabel.text=[[currentObject objectForKey:@"user"]objectForKey:@"screen_name"];
                cell.detailTextLabel.text=[currentObject objectForKey:@"text"];
    
            });
            
        });

   
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90;
}
@end
