//
//  ViewController.m
//  FHSTwitterDemo
//
//  Created by Divya Vuppala on 30/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "HomeViewController.h"
NSString *strClientKey=@"NAsHuSMgnelv7FhcTFx2Q7t3P";
NSString *strClientSecret=@"dHhGYxRkb31RqwU5xnCWOAVdp4YIoDzMQoIugUVZm0vofG2py7";


@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIButton *logIn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    logIn.frame = CGRectMake(100, 100, 100, 100);
    [logIn setTitle:@"Login" forState:UIControlStateNormal];
    [logIn addTarget:self action:@selector(showLoginWindow:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:logIn];
    
    [[FHSTwitterEngine sharedEngine]permanentlySetConsumerKey:strClientKey andSecret:strClientSecret];
    [[FHSTwitterEngine sharedEngine]setDelegate:self];

}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[FHSTwitterEngine sharedEngine]loadAccessToken];
    NSString *username = [[FHSTwitterEngine sharedEngine]authenticatedUsername];
    if (username.length > 0) {
        NSLog(@"%@", [NSString stringWithFormat:@"Logged in as %@",username]);
        
    } else {
        NSLog( @"You are not logged in.");
    }
    
}
- (void)storeAccessToken:(NSString *)accessToken {
    [[NSUserDefaults standardUserDefaults]setObject:accessToken forKey:@"SavedAccessHTTPBody"];
}

- (NSString *)loadAccessToken {
    return [[NSUserDefaults standardUserDefaults]objectForKey:@"SavedAccessHTTPBody"];
}

- (void)showLoginWindow:(id)sender
{
    [self presentViewController:[[FHSTwitterEngine sharedEngine]loginControllerWithCompletionHandler:^(BOOL success) {
        NSLog(success?@"L0L success":@"O noes!!! Loggen faylur!!!");
    }]
                       animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    TweetsTableViewController *obj=(TweetsTableViewController*)segue.destinationViewController;
    obj.searchTweetsString=self.searchTextField.text;
}

- (IBAction)searchButton:(UIButton *)sender
{
    [self performSegueWithIdentifier:@"tweetSegue" sender:nil];
}
@end
