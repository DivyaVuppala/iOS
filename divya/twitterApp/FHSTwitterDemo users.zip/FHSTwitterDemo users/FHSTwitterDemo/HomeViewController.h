//
//  ViewController.h
//  FHSTwitterDemo
//
//  Created by Divya Vuppala on 30/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FHSTwitterEngine.h"
#import "TweetsTableViewController.h"

@interface HomeViewController : UIViewController<FHSTwitterEngineAccessTokenDelegate>
@property (weak, nonatomic) IBOutlet UITextField *searchTextField;
- (IBAction)searchButton:(UIButton *)sender;


@end

