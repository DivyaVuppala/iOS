//
//  TweetsTableViewController.h
//  FHSTwitterDemo
//
//  Created by Divya Vuppala on 04/05/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FHSTwitterEngine.h"

@interface TweetsTableViewController : UITableViewController
@property (nonatomic,strong) NSString *searchTweetsString;
@property (nonatomic,strong) NSArray *tweetsArray;
@end
