//
//  ViewController.h
//  Uploadimage
//
//  Created by Madhukumar on 23/02/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
/*!
 *@brief creating an outlet for imageview
 
 */
@property (weak, nonatomic) IBOutlet UIImageView *imageview;
/*!
 *@brief uploading image through button
  *@discussion by using NSurl getting data from server 
 and converting into NSData and displaying the image by accessing imageview property
 *@param sender is an argument

 */
- (IBAction)uploadimage:(id)sender;


@end

