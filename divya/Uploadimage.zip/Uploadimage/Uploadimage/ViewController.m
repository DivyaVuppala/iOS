//
//  ViewController.m
//  Uploadimage
//
//  Created by Madhukumar on 23/02/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)uploadimage:(id)sender {
 
   
    //getting data from server by using NSURL
    NSURL *url=[[NSURL alloc]initWithString:@"http://images.mapsofworld.com/travel/pictures-of-taj-mahal-in-agra-2.jpg"];
    //creating an url request
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    
    //response object
    NSURLResponse *response = nil;
    //error object
    NSError *error = nil;
      //creating a url connection and storing response in the form of NSData
    NSData *data= [NSURLConnection sendSynchronousRequest:request
                                           returningResponse:&response error:&error];
   
 
 

   
    //setting image to imageview from NSData
   self.imageview.image=[[UIImage alloc]initWithData:data];
   
}
@end
