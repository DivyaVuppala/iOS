//
//  TableViewController.h
//  CoreDataContactList
//
//  Created by Divya Vuppala on 19/03/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "ContactList.h"

@interface TableViewController : UITableViewController<NSFetchedResultsControllerDelegate>

@property NSManagedObjectContext *context;
@property NSFetchedResultsController *frc;
//@property NSFetchedResultsController *frc1;

@end
