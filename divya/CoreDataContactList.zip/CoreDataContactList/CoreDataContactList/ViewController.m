//
//  ViewController.m
//  CoreDataContactList
//
//  Created by Divya Vuppala on 19/03/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "ContactList.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    AppDelegate *apd=[UIApplication sharedApplication].delegate;
    self.context=apd.managedObjectContext;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)saveButton:(UIBarButtonItem *)sender
{
    
    ContactList *user=[NSEntityDescription insertNewObjectForEntityForName:@"ContactList" inManagedObjectContext:self.context];
    if (user!=nil)
    {
        user.name=self.nameTextField.text;
        user.emailID=self.emailTextField.text;
        user.phoneNumber=self.phoneNumberTextField.text;
    }
    NSError *error;
    if([self.context save:&error])
    {
        NSLog(@"saved");
    }
    [self.navigationController popViewControllerAnimated:YES];
}
@end
