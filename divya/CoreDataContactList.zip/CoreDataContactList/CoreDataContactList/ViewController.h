//
//  ViewController.h
//  CoreDataContactList
//
//  Created by Divya Vuppala on 19/03/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *emailTextField;
@property (weak, nonatomic) IBOutlet UITextField *phoneNumberTextField;

@property NSManagedObjectContext *context;

- (IBAction)saveButton:(UIBarButtonItem *)sender;

@end

