//
//  ContactList.m
//  CoreDataContactList
//
//  Created by Divya Vuppala on 19/03/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "ContactList.h"


@implementation ContactList

@dynamic name;
@dynamic emailID;
@dynamic phoneNumber;

@end
