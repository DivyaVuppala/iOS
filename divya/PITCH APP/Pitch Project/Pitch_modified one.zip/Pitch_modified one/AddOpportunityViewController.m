//
//  AddOpportunityViewController.m
//  Pitch
//
//  Created by Divya Vuppala on 03/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "AddOpportunityViewController.h"
#import "AddProductTableViewCell.h"

@interface AddOpportunityViewController ()

@end

@implementation AddOpportunityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.productsGroupTableView.delegate=self;
    self.productsGroupTableView.dataSource=self;
    
    UINib *nib=[UINib nibWithNibName:@"AddProductTableViewCell" bundle:nil];
    [self.productsGroupTableView registerNib:nib forCellReuseIdentifier:@"productCell"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    AddProductTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"productCell" forIndexPath:indexPath];
    
   // - (void)scrollToRowAtIndexPath:(NSIndexPath *)indexPath atScrollPosition:(UITableViewScrollPosition)scrollPosition animated:(BOOL)animated;
    

    
    return cell;
}

//
//-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
//{
//    return 40;
//}
//
//-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
//{
//    return 50;
//}
//
//-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
//{
//    
//    headerView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 40)];
//    headerView.backgroundColor=[UIColor orangeColor];
//    
//    UIButton *addButton=[[UIButton alloc]initWithFrame:CGRectMake(330, 10, 20, 20)];
//    [addButton setImage:[UIImage imageNamed:@"Add button.jpg"] forState:UIControlStateNormal];
//    [addButton addTarget:self action:@selector(buttonClicked) forControlEvents:UIControlEventTouchUpInside];
//    [headerView addSubview:addButton];
//    
//    UILabel *label1=[[UILabel alloc]initWithFrame:CGRectMake(50, 0, 150, 50)];
//    label1.text=@"Product Group";
//    [headerView addSubview:label1];
//    
//    UILabel *label2=[[UILabel alloc]initWithFrame:CGRectMake(230, 0, 150, 50)];
//    label2.text=@"Split %";
//    [headerView addSubview:label2];
//    return headerView;
//    
//}
//
//-(void)scrollViewDidScroll:(UIScrollView *)scrollView
//{
//    headerView.transform=CGAffineTransformMakeTranslation(0, scrollView.contentOffset.y);
//}
//
//- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    // this is needed to prevent cells from being displayed above our static view
//    [tableView bringSubviewToFront:headerView];
//}

-(void)buttonClicked
{
    
    
}

//-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
//{
//    
//    footerView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 40)];
//    footerView.backgroundColor=[UIColor whiteColor];
//    
//    UIButton *saveButton=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 185,50)];
//    [saveButton setTitle:@"save" forState:UIControlStateNormal];
//    [saveButton setBackgroundColor:[UIColor orangeColor]];
//    [saveButton addTarget:self action:@selector(buttonClicked) forControlEvents:UIControlEventTouchUpInside];
//    [footerView addSubview:saveButton];
//    
//    
//    UIButton *cancelButton=[[UIButton alloc]initWithFrame:CGRectMake(190, 0, 185,50)];
//    [cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
//    [cancelButton setBackgroundColor:[UIColor orangeColor]];
//    [cancelButton addTarget:self action:@selector(buttonClicked) forControlEvents:UIControlEventTouchUpInside];
//    [footerView addSubview:cancelButton];
//    
//    return footerView;
//    
//    
//}

@end

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


