//
//  AccountOpportunityViewController.h
//  HiPitchProject
//
//  Created by priteesh on 03/04/2015.
//  Copyright (c) 2015 priteesh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductGroupCustomTableViewCell.h"
@interface AccountOpportunityViewController : UIViewController
{
    NSArray * productGroupArray;
}

@end
