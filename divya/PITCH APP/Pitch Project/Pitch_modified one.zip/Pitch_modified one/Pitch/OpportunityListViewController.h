//
//  OpportunityListViewController.h
//  Pitch
//
//  Created by Divya Vuppala on 08/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OpportunityListViewController : UITableViewController

@end
