//
//  AccountsViewController.m
//  HiPitchProject
//
//  Created by priteesh on 03/04/2015.
//  Copyright (c) 2015 priteesh. All rights reserved.
//

#import "AccountsViewController.h"

@interface AccountsViewController ()

@end

@implementation AccountsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   [self.mytableview setDelegate:self];
  [self.mytableview setDataSource:self];
    self.navigationItem.title=@"Accounts";
    [[UINavigationBar appearance] setTintColor:[UIColor redColor]];
    arry=[[NSArray alloc]initWithObjects:@"one",@"two",@"three",@"four", nil];
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:12.0/255.0 green:37.0/255.0 blue:60.0/255.0 alpha:1.0];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    
   
}
- (IBAction)AddButtonTapped:(id)sender {
    
    AddOpportunityViewController *addOpp=[[AddOpportunityViewController alloc]init];
    [self.navigationController pushViewController:addOpp animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return arry.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Custom *cell = [tableView dequeueReusableCellWithIdentifier:@"mycell"];
    if (!cell) {
        
        [tableView registerNib:[UINib nibWithNibName:@"Custom" bundle:nil] forCellReuseIdentifier:@"mycell"];
        cell=[tableView dequeueReusableCellWithIdentifier:@"mycell"];
            }
    
    
    return cell;
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(Custom *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.labelName.text=[arry objectAtIndex:indexPath.row];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AccountOpportunityViewController *acv=[[AccountOpportunityViewController alloc]init];
    [self.navigationController pushViewController:acv animated:YES];
}


@end
