//
//  AccountListTableViewController.m
//  Pitch
//
//  Created by Divya Vuppala on 03/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import "AccountListTableViewController.h"
#import "TableViewCell.h"
#import "AddOpportunityViewController.h"
@interface AccountListTableViewController ()

@end

@implementation AccountListTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=@"Accounts";
    [[UINavigationBar appearance] setTintColor:[UIColor redColor]];
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:12.0/255.0 green:37.0/255.0 blue:60.0/255.0 alpha:1.0];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];

    accountArray = [[NSArray alloc]initWithObjects:@"one",@"two",@"three",@"four",@"five",@"six", nil];
   
    UINib *nib=[UINib nibWithNibName:@"TableViewCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"AccountsCell"];
    
    
    // web service
    
    NSURL *urlActivities =[NSURL URLWithString:@"https://pscrmuat.cognizant.com/PSIGW/PeopleSoftServiceListeningConnector/"];
    
    NSString *soapMsg=[NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:oppty_update=\"http://blackberry.compass/crm srch\"><soapenv:Header/><soapenv:Body><MyAccounts><EmployeeId>101036</EmployeeId></MyAccounts></soapenv:Body></soapenv:Envelope>"];
    
    NSMutableURLRequest *requests = [[NSMutableURLRequest alloc] initWithURL:urlActivities];
    requests.timeoutInterval = 30;
    NSString *msgLength = [NSString stringWithFormat:@"%lu",(unsigned long)[soapMsg length]];
    
    [requests setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [requests setValue:msgLength forHTTPHeaderField:@"Content-Length"];
    [requests setValue:@"CT_BB_MYACCOUNTS.VERSION_1" forHTTPHeaderField:@"SOAPAction"];
    [requests setHTTPMethod:@"POST"];
    [requests setHTTPBody:[soapMsg dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLResponse *response;
    
    NSError *error;
    NSData   *data = (NSMutableData *) [NSURLConnection sendSynchronousRequest:requests returningResponse:&response error:&error];
    NSString *s = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    NSLog(@"%@",s);

    //xml parsing
    
    NSXMLParser *parser=[[NSXMLParser alloc]initWithData:data];
    parser.delegate=self;
    [parser parse];

    

}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
    
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    NSLog(@"%@",elementName);
}

-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    NSLog(@"%@",string);
}

-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    NSLog(@"%@",elementName);
}

-(void)parserDidEndDocument:(NSXMLParser *)parser
{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return 5;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
   
   TableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"AccountsCell" forIndexPath:indexPath];
    
    cell.textLabel.text=[accountArray objectAtIndex:indexPath.row];
    
    cell.detailTextLabel.text=[accountArray objectAtIndex:indexPath.row];
    // Configure the cell...
    
    return cell;
}

#pragma mark -toBeRemoved

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    AddOpportunityViewController *aovc=[[AddOpportunityViewController alloc]initWithNibName:@"AddOpportunityViewController" bundle:nil];
//    [self.navigationController pushViewController:aovc animated:YES];
//    
    AccountsViewController * accountView=[[AccountsViewController alloc]init];
    [self.navigationController pushViewController:accountView animated:YES];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here, for example:
    // Create the next view controller.
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:<#@"Nib name"#> bundle:nil];
    
    // Pass the selected object to the new view controller.
    
    // Push the view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
