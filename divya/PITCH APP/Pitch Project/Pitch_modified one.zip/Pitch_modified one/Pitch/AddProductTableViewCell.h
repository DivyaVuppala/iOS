//
//  AddProductTableViewCell.h
//  Pitch
//
//  Created by Divya Vuppala on 03/04/15.
//  Copyright (c) 2015 CTS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddProductTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *favouriteImage;
- (IBAction)deleteButton:(UIButton *)sender;


@end
