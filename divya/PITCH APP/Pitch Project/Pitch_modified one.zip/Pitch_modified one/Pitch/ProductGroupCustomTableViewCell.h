//
//  ProductGroupCustomTableViewCell.h
//  HiPitchProject
//
//  Created by priteesh on 03/04/2015.
//  Copyright (c) 2015 priteesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProductGroupCustomTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *groupNameLabel;

@end
