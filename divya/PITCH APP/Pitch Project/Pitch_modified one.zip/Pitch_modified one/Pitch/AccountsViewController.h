//
//  AccountsViewController.h
//  HiPitchProject
//
//  Created by priteesh on 03/04/2015.
//  Copyright (c) 2015 priteesh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Custom.h"
#import "AccountOpportunityViewController.h"
#import "AddOpportunityViewController.h"

@interface AccountsViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSArray * arry;
}
@property (weak, nonatomic) IBOutlet UITableView *mytableview;

@end
